import os
from flask import Blueprint, request, Response
from app.services.vuln import ScanCVE
from app.utils.download_nvd_feeds import download_all_nvd_json_gz_feeds
from ..db.nvd_data_db import nvd_db
from dotenv import load_dotenv
import json
import csv
from flask import Flask, Response,render_template
from io import BytesIO
import pandas as pd




vuln_bp = Blueprint('vuln', __name__, template_folder='templates')
load_dotenv()
'''domain=os.getenv("DOMAIN")
username=os.getenv("USER_NAME")
password=os.getenv("PASSWORD") '''



@vuln_bp.route('/', methods=['GET', 'POST'])
def ScanForVulnerabilities():

    """
    Downloads and saves the specified NVD (National Vulnerability Database) feed in JSON-GZ format from a remote server,
    and runs a vulnerability scan against the specified host using that feed.
    """
    domain=None
    username=None
    password=None
    args=request.args
    domain = args.get('domain',domain)
    username = args.get('username', username)
    password = args.get('password', password)
    host_identifier = args.get('host_identifier')
    nvd_feed = args.get('nvd_feed')
    nvd_feed_year = args.get('nvd_feed_year', '2002')
    if not (domain and username and password and nvd_feed_year and int(nvd_feed_year) in list(range(2002, 2024))):
        return False
    resources_path = os.path.join(os.path.dirname(os.path.dirname("__file__")), 'resources')
    file_name = f"nvdcve-1.1-{nvd_feed_year}.json.gz"
    feed_full_path = os.path.join(resources_path, file_name)
    scve = ScanCVE(domain=domain, username=username, password=password, host_identifier=host_identifier, nvd_feed=feed_full_path)
    return Response(json.dumps(scve.run()), status=200, mimetype='application/json')


@vuln_bp.route('/nvd/feeds/download', methods=['GET', 'POST'])

def DownloadAllNVDFeeds():

    """
    This API endpoint downloads all available NVD feeds in JSON-GZ format from the NVD server.
    The downloaded files are stored on the local disk and can be used to perform vulnerability scans.
    
    return: A Flask response object containing a message indicating whether the download was successful.
    """
    download_all_nvd_json_gz_feeds()
    return Response("All NVD feeds downloaded successfully", status=200, mimetype='application/json')


'''@vuln_bp.route('/scan', methods=['GET', 'POST'])

def NVDAPI():

    """
    This API endpoint queries the database for known vulnerabilities associated with a given host.
    If vulnerabilities are found in the host, it compares them against the database and returns the 
    results of the vulnerability scan as JSON data.
    """
    nvd_test=nvd_db()
    return Response(nvd_test, status=200, mimetype='application/json')'''


@vuln_bp.route('/scan/download', methods=['GET', 'POST'])

def NVDAPI_download():

    """
    This API endpoint queries the database for known vulnerabilities associated with a given host.
    If vulnerabilities are found in the host, it compares them against the database and returns the 
    results of the vulnerability scan as JSON data.
    """
    nvd_test=nvd_db()
    if nvd_test == None:
        return json.dumps({})
    else:
        data = json.loads(nvd_test)
        df=pd.DataFrame(data)
        csv=df.to_csv(index=False)
        response=Response(csv,mimetype='text/csv')
        response.headers.set('Content-Disposition', 'attachment', filename='vuln.csv')
        
        return response

@vuln_bp.route('/', methods=['GET'])
def index():
    templates_path = os.environ.get('TEMPLATES_PATH')
    return render_template(templates_path)

   