#!/usr/bin/env python
# -*- coding: utf-8 -*-
""" 
Script for scaning the vulnerabilities from installed applications .
:copyright: (c) 2023 by EclecticIQ.
:license: MIT, see LICENSE for more details.

To run it:
1. Install python and python required modules mentioned in requirements.txt
2. Install go lang, install https://github.com/facebookincubator/nvdtools and make sure they are available
3. Download the NVD feed with .json.gz format
4. Run the script using the required command line arguments using installed python version
"""

import copy
import subprocess

from app.er.api import ErAPI


class ScanCVE:
    splitter = ','

    def __init__(self, domain=None, username=None, password=None, host_identifier=None, nvd_feed=None):
        self.host_identifier = host_identifier
        self.er_api = ErAPI(username=username, password=password, domain=domain)
        self.nvd_feed = 'nvdcve-1.1-modified.json'
        self.sql_windows = """SELECT 'a' AS part, publisher AS vendor, name AS product, version \
        AS version FROM programs WHERE name IS NOT NULL AND name <> '';"""
        self.sql_darwin = """SELECT 'a' AS part, '' AS vendor, bundle_name AS product, bundle_version AS version FROM apps WHERE bundle_name IS NOT NULL AND bundle_name <> '';"""
        self.sql_ubuntu = """SELECT 'a' AS part, '' AS vendor, name AS product, version AS version FROM deb_packages WHERE name IS NOT NULL AND name <> '';"""
        self.sql_rhel = """SELECT 'a' AS part, '' AS vendor, name AS product, version AS version FROM rpm_packages WHERE name IS NOT NULL AND name <> '';"""
        self.command = """echo '{0}' | csv2cpe -x -lower -cpe_part=1 -cpe_vendor=2 -cpe_product=3 \
        -cpe_version=4 | cpe2cve -cpe 1 -e 1 -cve 1 {1}"""
        self.csv2cpe_command = """echo '{0}' | csv2cpe -x -lower -cpe_part=1 -cpe_vendor=2 -cpe_product=3 -cpe_version=4"""
        self.sql_distributed_per_platform_dict = {'windows': self.sql_windows, 'darwin': self.sql_darwin, 'ubuntu': self.sql_ubuntu, 'rhel': self.sql_rhel}
        self.sql_scheduled_per_platform_dict = {'windows': "programs", 'ubuntu': 'deb_packages', 'rhel': 'rpm_packages', 'darwin': 'installed_applications'}
        self.hosts_dict = {"online": {'windows': [], 'ubuntu': [], 'rhel': [], 'darwin': []}, "offline": {'windows': [], 'ubuntu': [], 'rhel': [], 'darwin': []}}
        self.columns_trans_dict = {'windows': {'publisher': 'vendor', 'name': 'product', 'version': 'version'}, 'ubuntu': {'name': 'product', 'version': 'version'}, 'rhel': {'name': 'product', 'version': 'version'}, 'darwin': {'bundle_name': 'product', 'bundle_version': 'version'}}
        self.csv_dict_sample = {'part': 'a', 'vendor': '', 'product': '', 'version': ''}
        self.main_output = []
        self.csv_data=[]

    def run(self):
        if self.host_identifier:
            status = self.er_api.get_a_host_status(host_identifier=self.host_identifier)
            platform = self.er_api.get_platform_of_a_host(host_identifier=self.host_identifier)
            if status:
                status_string = "online"
            else:
                status_string = "offline"
            self.hosts_dict[status_string][platform].append(self.host_identifier)
        else:
            active_hosts, inactive_hosts = self.er_api.get_online_offline_hosts()
            active_hosts_platform_dict = self.get_platform_hosts_dict(active_hosts)
            for platform, hosts_list in active_hosts_platform_dict.items():
                self.hosts_dict['online'][platform].extend(hosts_list)
            inactive_hosts_platform_dict = self.get_platform_hosts_dict(inactive_hosts)
            for platform, hosts_list in inactive_hosts_platform_dict.items():
                self.hosts_dict['offline'][platform].extend(hosts_list)

        for platform, hosts_array in self.hosts_dict['online'].items():
            sql = self.sql_distributed_per_platform_dict[platform]
            results = self.er_api.query_live(sql=sql, host_identifiers=hosts_array)
            csv_array_dict = {}
            for host_identifier, data_node_dict in results.items():
                csv_array_dict[host_identifier] = self.get_installed_programs_csv(data_node_dict['data'])

            for host, csv_array in csv_array_dict.items():
                vulnerable_found = False
                for csv in csv_array:
                    #vulnerable_found = False
                    csv_parts_data=csv.split(',')
                    self.csv_data.append({'application':csv_parts_data[0],'vendor':csv_parts_data[1],'product':csv_parts_data[2],'version':csv_parts_data[3],'host':host})
                                         
                    '''command = self.command.format(csv, self.nvd_feed)
                    command = self.csv2cpe_command.format(csv,self.csv2cpe_command)
                    print(command)
                    output = subprocess.getoutput(command)
                    if output:
                        vulnerable_found = True
                        part, vendor, product, version = csv.split(self.splitter)

                        self.main_output.append({'application': product, 'version': version, 'host_identifier': host, 'CVE': output})
                if not vulnerable_found:
                    print("No vulnerable found in the host: {}".format(host))
                else:
                    print("Vulnerables found in the host: {}".format(host))  '''

        for platform, hosts_array in self.hosts_dict['offline'].items():
            csv_array_dict = {}
            for host_id in hosts_array:
                new_results = []
                query_name = self.sql_scheduled_per_platform_dict[platform]
                results = self.er_api.get_all_query_results(query_name=query_name, host_identifier=host_id)
                for result in results:
                    new_result = copy.deepcopy(self.csv_dict_sample)
                    for from_key, to_key in self.columns_trans_dict[platform].items():
                        new_result[to_key] = result['columns'][from_key]
                    new_results.append(new_result)
                csv_array_dict[host_id] = self.get_installed_programs_csv(new_results)

            for host, csv_array in csv_array_dict.items():
                #vulnerable_found = False
                for csv in csv_array:
                    csv_parts_data=csv.split(',')
                    self.csv_data.append({'application':csv_parts_data[0],'vendor':csv_parts_data[1],'product':csv_parts_data[2],'version':csv_parts_data[3],'host':host})
                    '''command = self.csv2cpe_command.format(csv, self.csv2cpe_command)
                    output = subprocess.getoutput(command)
                    
                    if output:
                        vulnerable_found = True
                        part, vendor, product, version = csv.split(self.splitter)
                        self.main_output.append({'application': product, 'version': version, 'host_identifier': host, 'CVE': output})
                if not vulnerable_found:
                    print("No vulnerable found in the host: {}".format(host))
                else:
                    ("Vulnerables found in the host: {}".format(host))'''
         
        return self.csv_data
        #return self.main_output 
    @staticmethod
    def get_platform_hosts_dict(all_hosts):
        hosts_platform_dict = {}
        for host in all_hosts:
            if 'os_info' in host and 'platform' in host['os_info']:
                platform = host['os_info']['platform']
            elif 'host_details' in host and 'osquery_info' in host['host_details'] and 'build_platform' in host['host_details']['osquery_info']:
                if host['host_details']['osquery_info']['build_platform'] == 'windows' or host['host_details']['osquery_info']['build_platform'] == 'darwin':
                    platform = host['host_details']['osquery_info']['build_platform']
                else:
                    if 'os_info' in host and 'name' in host['os_info'] and host['os_info']['name']:
                        if host['os_info']['name'].startswith('Ubuntu'):
                            platform = "ubuntu"
                        elif host['os_info']['name'].startswith('Red Hat Enterprise'):
                            platform = "rhel"
            if platform in hosts_platform_dict:
                hosts_platform_dict[platform].append(host['host_identifier'])
            else:
                hosts_platform_dict[platform] = [host['host_identifier']]
        return hosts_platform_dict

    def get_installed_programs_csv(self, data):
        filtered_list = []
        for result in data:
            vendor_word_list = result['vendor'].split(" ")
            product = result['product']
            vendor = result['vendor']
            for item in vendor_word_list:
                if item == "The":
                    continue
                else:
                    vendor = item.lower()
                    break
            product_word_list = result['product'].split(" ")
            for item in product_word_list:
                if item == "The":
                    continue
                else:
                    product = item.lower()
                    break
            filtered_list.append(
                self.splitter.join([result['part'], vendor.replace(',', ''), product.replace(',', ''), result['version']]))
        return filtered_list
