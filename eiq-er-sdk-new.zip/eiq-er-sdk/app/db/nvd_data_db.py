import json
import requests
import sqlite3
from ..utils.download_nvd_feeds import nvd_api
from ..services.vuln import ScanCVE
import json
import asyncio
from dotenv import load_dotenv
import os 

load_dotenv()
domain=os.getenv("DOMAIN")
username=os.getenv("USER_NAME")
password=os.getenv("PASSWORD")
api_key=os.getenv("API_KEY")
url=os.getenv("URL")

def nvd_db():
    """
    This function creates a SQLite database to store information about vulnerabilities obtained from the NVD API. It
    first checks if the database is empty. If it is empty, it populates the database with data from the NVD API. If it
    is not empty, it scans for vulnerabilities on a specified domain and checks if they are present in the database.
    """
    conn = sqlite3.connect('nvd_api_db.db')
    cursor = conn.cursor()
    cursor.execute(
        '''CREATE TABLE IF NOT EXISTS vulnerabilities 
             (cve_id TEXT PRIMARY KEY,
              source_identifier TEXT,
              cve_description TEXT,
              cvssMetricV2_details TEXT,
              cpe_match_criteria TEXT,
              cpe_name_match
              );''')

    cursor.execute('SELECT COUNT(*) FROM vulnerabilities')
    count = cursor.fetchone()[0]

    if count == 0:
        #datas = asyncio.run(run_coroutine())
        datas=nvd_api()
        cursor = conn.cursor()

        for item in datas:

            #item = json.loads(item_dict)
            result = item.get('result')
            if result['resultsPerPage']!= 0:
                for first_vulnerability in result['vulnerabilities']:
                    cve_id = first_vulnerability['cve']['id']
                    cve_source_identifier=first_vulnerability['cve']['sourceIdentifier']
                    cve_description=[]
                    for description in first_vulnerability['cve']['descriptions']:
                        if description['lang']=='en':
                            cve_description.append({'description':description})
                    cpe_match_criteria=[]
                    configuration=first_vulnerability['cve']['configurations']
                    for conf in configuration:
                        for node in conf['nodes']:
                            for cpe in node['cpeMatch']:
                                if cpe['vulnerable']== True:
                                    cpe_match_criteria.append({'affected_areas':{"vulnerable":cpe['vulnerable'],"criteria":cpe['criteria'],"math_criteria":cpe['matchCriteriaId']}})

                    cvss_base_score = None
                    Severity = None
                    impact_score = None
                    if 'cvssMetricV31' in first_vulnerability['cve']['metrics']:
                        cvss_base_score = first_vulnerability['cve']['metrics']['cvssMetricV31'][0]['cvssData']['baseScore']
                        Severity = first_vulnerability['cve']['metrics']['cvssMetricV31'][0]['cvssData']['baseSeverity']
                        impact_score = first_vulnerability['cve']['metrics']['cvssMetricV31'][0]['impactScore']
                        cvss_matching_details=[{'base_score':cvss_base_score,'Severity':Severity,'impact_score':impact_score}]
                        cvss_metrics = {f"{key}_{i+1}": value for i, (key, value) in enumerate(cvss_matching_details[0].items())}
                        cvssMetricV31_details=json.dumps([{'cvss_metricsV31_details': cvss_metrics}])

                    elif 'cvssMetricV30' in first_vulnerability['cve']['metrics']:
                        cvss_base_score = first_vulnerability['cve']['metrics']['cvssMetricV30'][0]['cvssData']['baseScore']
                        Severity = first_vulnerability['cve']['metrics']['cvssMetricV30'][0]['cvssData']['baseSeverity']
                        impact_score = first_vulnerability['cve']['metrics']['cvssMetricV30'][0]['impactScore']
                        cvss_matching_details=[{'base_score':cvss_base_score,'Severity':Severity,'impact_score':impact_score}]
                        cvss_metrics = {f"{key}_{i+1}": value for i, (key, value) in enumerate(cvss_matching_details[0].items())}
                        cvssMetricV31_details=json.dumps([{'cvss_metricsV30_details': cvss_metrics}])

                    else :
                        cvss_base_score = first_vulnerability['cve']['metrics']['cvssMetricV2'][0]['cvssData']['baseScore']
                        Severity = first_vulnerability['cve']['metrics']['cvssMetricV2'][0]['baseSeverity']
                        impact_score = first_vulnerability['cve']['metrics']['cvssMetricV2'][0]['impactScore']
                        cvss_matching_details=[{'base_score':cvss_base_score,'Severity':Severity,'impact_score':impact_score}]
                        cvss_metrics = {f"{key}_{i+1}": value for i, (key, value) in enumerate(cvss_matching_details[0].items())}
                        cvssMetricV2_details=json.dumps([{'cvss_metricsV2_details': cvss_metrics}])
                    
                    cursor.execute('''INSERT OR IGNORE INTO vulnerabilities (cve_id, source_identifier,cve_description,cvssMetricV2_details,cpe_match_criteria
                    ,cpe_name_match)
                                VALUES (?, ?, ?, ?, ?, ?)''',(cve_id, cve_source_identifier,json.dumps(cve_description),cvssMetricV2_details,json.dumps(cpe_match_criteria),item.get('cpe_name')))
                    conn.commit()
    else:
        vulnerability_find=find_vulnerability()
        return json.dumps(vulnerability_find)
    


def find_vulnerability():

    """
    This function will return a list of vulnerability results comparing with db
    """
    conn = sqlite3.connect('nvd_api_db.db')
    cursor = conn.cursor()
    cursor.execute('''SELECT * FROM vulnerabilities ;''')
    rows = cursor.fetchall()
    scve=ScanCVE(domain=domain, username=username, password=password)
    results=scve.run()
    cpe_results=[]

    for result in results:
        cpe_host_part=result['application']
        cpe_host_product=result['vendor']
        cpe_host_vendor=result['product']
        cpe_host_version=result['version']
        host=result['host']
        
        
        for row in rows:
            cve_id=row[0]
            cve_descriptions=json.loads(row[2])
            cve_description=cve_descriptions[0]['description']['value']
            cpe_name_match=row[5].split(':')
            cpe_name_match_part=cpe_name_match[2]
            cpe_name_match_product=cpe_name_match[3]
            cpe_name_match_vendor=cpe_name_match[4]
            cpe_name_match_version=cpe_name_match[5]

        
        
            if cpe_name_match_part==cpe_host_part and \
                    cpe_host_product==cpe_name_match_product and \
                    cpe_name_match_vendor == cpe_host_vendor and \
                    cpe_name_match_version==cpe_host_version:
                    vulnerable_result={
                                "Vulnerable":True,
                                "Host__Identifier": f"{host}",
                                "CVE_ID": f"{cve_id}",
                                "description": f"{cve_description}"
                            }
                    cpe_results.append(vulnerable_result)
                    print(vulnerable_result)
            
    scan_insert=scan_and_insert()

    
    conn.commit()
    return scan_insert


def scan_and_insert():

    """
    Calling nvd_api iterating through results and inserting new vulnerabilties into database if found
    """

    conn = sqlite3.connect('nvd_api_db.db')
    cursor = conn.cursor()
    datas=nvd_api()

    cursor = conn.cursor()
    vulnerabilities_found = False
    cpe_results=[]
    if datas is not None:
        for item in datas:
            result = item.get('result')
            host=item.get('cve_data_host')
            if result['resultsPerPage']!= 0:
                for first_vulnerability in result['vulnerabilities']:
                    cve_id = first_vulnerability['cve']['id']
                    cve_source_identifier=first_vulnerability['cve']['sourceIdentifier']
                    cve_description=[]
                    for description in first_vulnerability['cve']['descriptions']:
                        if description['lang']=='en':
                            cve_description.append({'description':description})
                    cpe_match_criteria=[]
                    configuration=first_vulnerability['cve']['configurations']
                    for conf in configuration:
                        for node in conf['nodes']:
                            for cpe in node['cpeMatch']:
                                if cpe['vulnerable']== True:
                                    cpe_match_criteria.append({'affected_areas':{"vulnerable":cpe['vulnerable'],"criteria":cpe['criteria'],"math_criteria":cpe['matchCriteriaId']}})
                    
                    cvss_base_score = None
                    Severity = None
                    impact_score = None
                    if 'cvssMetricV31' in first_vulnerability['cve']['metrics']:
                        cvss_base_score = first_vulnerability['cve']['metrics']['cvssMetricV31'][0]['cvssData']['baseScore']
                        Severity = first_vulnerability['cve']['metrics']['cvssMetricV31'][0]['cvssData']['baseSeverity']
                        impact_score = first_vulnerability['cve']['metrics']['cvssMetricV31'][0]['impactScore']
                        cvss_matching_details=[{'base_score':cvss_base_score,'Severity':Severity,'impact_score':impact_score}]
                        cvss_metrics = {f"{key}_{i+1}": value for i, (key, value) in enumerate(cvss_matching_details[0].items())}
                        cvssMetricV31_details=json.dumps([{'cvss_metricsV31_details': cvss_metrics}])

                    elif 'cvssMetricV30' in first_vulnerability['cve']['metrics']:
                        cvss_base_score = first_vulnerability['cve']['metrics']['cvssMetricV30'][0]['cvssData']['baseScore']
                        Severity = first_vulnerability['cve']['metrics']['cvssMetricV30'][0]['cvssData']['baseSeverity']
                        impact_score = first_vulnerability['cve']['metrics']['cvssMetricV30'][0]['impactScore']
                        cvss_matching_details=[{'base_score':cvss_base_score,'Severity':Severity,'impact_score':impact_score}]
                        cvss_metrics = {f"{key}_{i+1}": value for i, (key, value) in enumerate(cvss_matching_details[0].items())}
                        cvssMetricV31_details=json.dumps([{'cvss_metricsV30_details': cvss_metrics}])

                    else :
                        cvss_base_score = first_vulnerability['cve']['metrics']['cvssMetricV2'][0]['cvssData']['baseScore']
                        Severity = first_vulnerability['cve']['metrics']['cvssMetricV2'][0]['baseSeverity']
                        impact_score = first_vulnerability['cve']['metrics']['cvssMetricV2'][0]['impactScore']
                        cvss_matching_details=[{'base_score':cvss_base_score,'Severity':Severity,'impact_score':impact_score}]
                        cvss_metrics = {f"{key}_{i+1}": value for i, (key, value) in enumerate(cvss_matching_details[0].items())}
                        cvssMetricV2_details=json.dumps([{'cvss_metricsV2_details': cvss_metrics}])
                    
                    host =host
                    cve_id=cve_id
                    cve_description=cve_description
                    cpe_result= {
                                "Vulnerable":True,
                                "Host_Identifier": f"{host}",
                                "CVE_ID": f"{cve_id}",
                                "description": f"{cve_description}"
                            }
                    cpe_results.append(cpe_result)
                    cursor.execute('''INSERT OR IGNORE INTO vulnerabilities (cve_id, source_identifier,cve_description,cvssMetricV2_details,cpe_match_criteria 
                    ,cpe_name_match)
                        VALUES (?, ?, ?, ?, ?, ?)''',(cve_id, cve_source_identifier,json.dumps(cve_description),cvssMetricV2_details,json.dumps(cpe_match_criteria),item.get('cpe_name')))
            
            else:    
                print("No vulnerable found on the host{0}".format(host))

    conn.commit()
    conn.close()
    return cpe_results
