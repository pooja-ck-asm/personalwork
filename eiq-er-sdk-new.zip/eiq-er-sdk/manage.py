import os 
from gevent.pywsgi import WSGIServer
from app.application import app
if __name__ == '__main__':
    if os.environ.get("FLASK_ENV") == "prod" or os.environ.get("FLASK_ENV") == "production":
        http_server = WSGIServer(('', 5000), app)
        http_server.serve_forever()
    else:
        app.run(debug=True, host="0.0.0.0", port="5000")
